package com.enterprise.ordersystem.payment.dto;

import com.enterprise.ordersystem.payment.model.Payment;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public class PaymentDto {

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class CreateRequest {
        @NotNull(message = "Order ID is required")
        private Long orderId;

        @NotNull(message = "User ID is required")
        private Long userId;

        @NotNull(message = "Amount is required")
        @DecimalMin(value = "0.01", message = "Amount must be positive")
        private BigDecimal amount;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class Response {
        private Long id;
        private Long orderId;
        private Long userId;
        private BigDecimal amount;
        private Payment.PaymentStatus status;
        private String transactionId;
        private String failureReason;
        private LocalDateTime createdAt;
        private LocalDateTime updatedAt;
    }
}
