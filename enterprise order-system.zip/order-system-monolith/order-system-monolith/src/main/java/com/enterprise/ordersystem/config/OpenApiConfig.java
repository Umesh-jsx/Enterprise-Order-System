package com.enterprise.ordersystem.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.tags.Tag;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.List;

@Configuration
public class OpenApiConfig {

    @Bean
    public OpenAPI orderSystemOpenAPI() {
        return new OpenAPI()
                .info(new Info()
                        .title("Enterprise Order System API")
                        .description("Single-module Spring Boot application combining User, Order, Payment, Inventory, and Gateway services.")
                        .version("1.0.0")
                        .contact(new Contact().name("Enterprise Order System")))
                .tags(List.of(
                        new Tag().name("User API").description("User management"),
                        new Tag().name("Order API").description("Order management with Saga + idempotency"),
                        new Tag().name("Payment API").description("Payment processing"),
                        new Tag().name("Inventory API").description("Inventory management with optimistic locking"),
                        new Tag().name("Gateway API").description("Route info and health")
                ));
    }
}
