package com.enterprise.ordersystem.order.dto;

import com.enterprise.ordersystem.order.model.Order;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public class OrderDto {

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class CreateRequest {

        @NotNull(message = "User ID is required")
        private Long userId;

        @NotBlank(message = "Product ID is required")
        private String productId;

        @NotNull(message = "Quantity is required")
        @Min(value = 1, message = "Quantity must be at least 1")
        private Integer quantity;

        @NotNull(message = "Total amount is required")
        @DecimalMin(value = "0.01", message = "Total amount must be positive")
        private BigDecimal totalAmount;

        /**
         * Client-generated unique key to prevent duplicate orders on retries.
         * Use a UUID per order attempt.
         */
        @NotBlank(message = "Idempotency key is required")
        @Size(max = 100, message = "Idempotency key max 100 chars")
        private String idempotencyKey;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class Response {
        private Long id;
        private Long userId;
        private String productId;
        private Integer quantity;
        private BigDecimal totalAmount;
        private Order.OrderStatus status;
        private String idempotencyKey;
        private String failureReason;
        private LocalDateTime createdAt;
        private LocalDateTime updatedAt;
    }
}
