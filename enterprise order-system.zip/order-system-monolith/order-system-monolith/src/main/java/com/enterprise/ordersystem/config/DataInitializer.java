package com.enterprise.ordersystem.config;

import com.enterprise.ordersystem.inventory.model.Inventory;
import com.enterprise.ordersystem.inventory.repository.InventoryRepository;
import com.enterprise.ordersystem.order.model.Order;
import com.enterprise.ordersystem.order.repository.OrderRepository;
import com.enterprise.ordersystem.payment.model.Payment;
import com.enterprise.ordersystem.payment.repository.PaymentRepository;
import com.enterprise.ordersystem.user.model.User;
import com.enterprise.ordersystem.user.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;

@Slf4j
@Component
@RequiredArgsConstructor
public class DataInitializer implements CommandLineRunner {

    private final UserRepository userRepository;
    private final OrderRepository orderRepository;
    private final PaymentRepository paymentRepository;
    private final InventoryRepository inventoryRepository;

    @Override
    public void run(String... args) {
        seedUsers();
        seedInventory();
        seedOrders();
        seedPayments();
        log.info("=== Data seeding complete ===");
        log.info("Users: {} | Orders: {} | Payments: {} | Products: {}",
                userRepository.count(),
                orderRepository.count(),
                paymentRepository.count(),
                inventoryRepository.count());
    }

    private void seedUsers() {
        if (userRepository.count() > 0) return;
        log.info("Seeding users...");
        userRepository.save(buildUser("Alice Johnson",  "alice@example.com",   "9876543210"));
        userRepository.save(buildUser("Bob Smith",      "bob@example.com",     "9876543211"));
        userRepository.save(buildUser("Charlie Brown",  "charlie@example.com", "9876543212"));
        userRepository.save(buildUser("Diana Prince",   "diana@example.com",   "9876543213"));
    }

    private void seedInventory() {
        if (inventoryRepository.count() > 0) return;
        log.info("Seeding inventory...");
        inventoryRepository.save(buildInventory("PROD-001", "Laptop Pro 15",        100));
        inventoryRepository.save(buildInventory("PROD-002", "Wireless Mouse",        500));
        inventoryRepository.save(buildInventory("PROD-003", "USB-C Hub",             250));
        inventoryRepository.save(buildInventory("PROD-004", "Mechanical Keyboard",   150));
        inventoryRepository.save(buildInventory("PROD-005", "4K Monitor",             75));
    }

    private void seedOrders() {
        if (orderRepository.count() > 0) return;
        log.info("Seeding orders...");

        Order o1 = new Order();
        o1.setUserId(1L);
        o1.setProductId("PROD-001");
        o1.setQuantity(2);
        o1.setTotalAmount(new BigDecimal("299.99"));
        o1.setIdempotencyKey("seed-order-001");
        o1.setStatus(Order.OrderStatus.COMPLETED);

        Order o2 = new Order();
        o2.setUserId(2L);
        o2.setProductId("PROD-002");
        o2.setQuantity(1);
        o2.setTotalAmount(new BigDecimal("49.99"));
        o2.setIdempotencyKey("seed-order-002");
        o2.setStatus(Order.OrderStatus.PAYMENT_PROCESSING);

        Order o3 = new Order();
        o3.setUserId(1L);
        o3.setProductId("PROD-003");
        o3.setQuantity(3);
        o3.setTotalAmount(new BigDecimal("89.97"));
        o3.setIdempotencyKey("seed-order-003");
        o3.setStatus(Order.OrderStatus.PENDING);

        orderRepository.save(o1);
        orderRepository.save(o2);
        orderRepository.save(o3);
    }

    private void seedPayments() {
        if (paymentRepository.count() > 0) return;
        log.info("Seeding payments...");

        Payment p1 = new Payment();
        p1.setOrderId(1L);
        p1.setUserId(1L);
        p1.setAmount(new BigDecimal("299.99"));
        p1.setStatus(Payment.PaymentStatus.SUCCESS);
        p1.setTransactionId("TXN-SEED0001");

        Payment p2 = new Payment();
        p2.setOrderId(2L);
        p2.setUserId(2L);
        p2.setAmount(new BigDecimal("49.99"));
        p2.setStatus(Payment.PaymentStatus.PROCESSING);
        p2.setTransactionId("TXN-SEED0002");

        paymentRepository.save(p1);
        paymentRepository.save(p2);
    }

    // ---- helpers ----

    private User buildUser(String name, String email, String phone) {
        User u = new User();
        u.setName(name);
        u.setEmail(email);
        u.setPhone(phone);
        u.setStatus(User.UserStatus.ACTIVE);
        return u;
    }

    private Inventory buildInventory(String productId, String name, int qty) {
        Inventory inv = new Inventory();
        inv.setProductId(productId);
        inv.setProductName(name);
        inv.setAvailableQuantity(qty);
        inv.setReservedQuantity(0);
        return inv;
    }
}
