package com.enterprise.ordersystem.gateway.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/gateway")
@Tag(name = "Gateway API")
public class GatewayController {

    @Value("${spring.application.name:order-system-monolith}")
    private String appName;

    @Value("${server.port:8080}")
    private String port;

    @Value("${kafka.enabled:false}")
    private boolean kafkaEnabled;

    @GetMapping("/info")
    @Operation(summary = "System information and route map")
    public ResponseEntity<Map<String, Object>> info() {
        Map<String, Object> info = new LinkedHashMap<>();
        info.put("application", appName);
        info.put("port", port);
        info.put("timestamp", LocalDateTime.now());
        info.put("kafkaEnabled", kafkaEnabled);
        info.put("sagaMode", kafkaEnabled ? "Event-driven (Kafka)" : "Synchronous (in-process)");

        Map<String, String> routes = new LinkedHashMap<>();
        routes.put("Users",        "http://localhost:" + port + "/api/users");
        routes.put("Orders",       "http://localhost:" + port + "/api/orders");
        routes.put("Payments",     "http://localhost:" + port + "/api/payments");
        routes.put("Inventory",    "http://localhost:" + port + "/api/inventory");
        routes.put("Swagger UI",   "http://localhost:" + port + "/swagger-ui.html");
        routes.put("OpenAPI JSON", "http://localhost:" + port + "/api-docs");
        routes.put("H2 Console",   "http://localhost:" + port + "/h2-console");
        routes.put("Actuator",     "http://localhost:" + port + "/actuator/health");
        info.put("routes", routes);

        return ResponseEntity.ok(info);
    }

    @GetMapping("/health")
    @Operation(summary = "Quick health check")
    public ResponseEntity<Map<String, String>> health() {
        return ResponseEntity.ok(Map.of(
                "status", "UP",
                "service", appName,
                "timestamp", LocalDateTime.now().toString()
        ));
    }
}
