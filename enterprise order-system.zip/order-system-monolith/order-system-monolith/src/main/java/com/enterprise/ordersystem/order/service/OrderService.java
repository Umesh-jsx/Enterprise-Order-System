package com.enterprise.ordersystem.order.service;

import com.enterprise.ordersystem.order.dto.OrderDto;
import com.enterprise.ordersystem.order.model.Order;
import com.enterprise.ordersystem.order.repository.OrderRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class OrderService {

    private final OrderRepository orderRepository;
    private final OrderSagaService sagaService;

    /**
     * Idempotent order creation.
     * Same idempotencyKey → returns existing order without re-processing.
     */
    @Transactional
    public OrderDto.Response createOrder(OrderDto.CreateRequest request) {
        log.info("Create order: userId={}, product={}, key={}",
                request.getUserId(), request.getProductId(), request.getIdempotencyKey());

        return orderRepository.findByIdempotencyKey(request.getIdempotencyKey())
                .map(existing -> {
                    log.warn("Duplicate order detected, returning existing id={}", existing.getId());
                    return toResponse(existing);
                })
                .orElseGet(() -> {
                    Order order = new Order();
                    order.setUserId(request.getUserId());
                    order.setProductId(request.getProductId());
                    order.setQuantity(request.getQuantity());
                    order.setTotalAmount(request.getTotalAmount());
                    order.setIdempotencyKey(request.getIdempotencyKey());
                    order.setStatus(Order.OrderStatus.CONFIRMED);

                    Order saved = orderRepository.save(order);
                    log.info("Order created with id: {}", saved.getId());

                    // Kick off Saga (synchronous in-process or via Kafka)
                    triggerSaga(saved);

                    return toResponse(saved);
                });
    }

    /**
     * Retry up to 3 times with exponential backoff if Saga trigger fails.
     */
    @Retryable(retryFor = Exception.class, maxAttempts = 3, backoff = @Backoff(delay = 1000, multiplier = 2))
    public void triggerSaga(Order order) {
        sagaService.onOrderCreated(order);
    }

    @Transactional(readOnly = true)
    public OrderDto.Response getOrderById(Long id) {
        return toResponse(orderRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Order not found: " + id)));
    }

    @Transactional(readOnly = true)
    public List<OrderDto.Response> getAllOrders() {
        return orderRepository.findAll().stream()
                .map(this::toResponse)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<OrderDto.Response> getOrdersByUser(Long userId) {
        return orderRepository.findByUserId(userId).stream()
                .map(this::toResponse)
                .collect(Collectors.toList());
    }

    @Transactional
    public OrderDto.Response cancelOrder(Long id) {
        Order order = orderRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Order not found: " + id));
        if (order.getStatus() == Order.OrderStatus.COMPLETED) {
            throw new IllegalStateException("Cannot cancel a completed order");
        }
        order.setStatus(Order.OrderStatus.CANCELLED);
        Order saved = orderRepository.save(order);
        // Saga compensation: release inventory for cancelled order
        sagaService.handleInventoryFailure(id, "Order cancelled by user");
        log.info("Order cancelled: {}", id);
        return toResponse(saved);
    }

    private OrderDto.Response toResponse(Order o) {
        return OrderDto.Response.builder()
                .id(o.getId())
                .userId(o.getUserId())
                .productId(o.getProductId())
                .quantity(o.getQuantity())
                .totalAmount(o.getTotalAmount())
                .status(o.getStatus())
                .idempotencyKey(o.getIdempotencyKey())
                .failureReason(o.getFailureReason())
                .createdAt(o.getCreatedAt())
                .updatedAt(o.getUpdatedAt())
                .build();
    }
}
