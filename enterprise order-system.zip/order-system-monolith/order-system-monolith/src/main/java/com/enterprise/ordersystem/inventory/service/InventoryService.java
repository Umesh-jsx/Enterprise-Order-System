package com.enterprise.ordersystem.inventory.service;

import com.enterprise.ordersystem.inventory.dto.InventoryDto;
import com.enterprise.ordersystem.inventory.model.Inventory;
import com.enterprise.ordersystem.inventory.model.InventoryReservation;
import com.enterprise.ordersystem.inventory.repository.InventoryRepository;
import com.enterprise.ordersystem.inventory.repository.InventoryReservationRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class InventoryService {

    private final InventoryRepository inventoryRepository;
    private final InventoryReservationRepository reservationRepository;

    @Transactional
    public InventoryDto.Response addInventory(InventoryDto.CreateRequest request) {
        if (inventoryRepository.findByProductId(request.getProductId()).isPresent()) {
            throw new IllegalArgumentException("Product already exists: " + request.getProductId());
        }
        Inventory inv = new Inventory();
        inv.setProductId(request.getProductId());
        inv.setProductName(request.getProductName());
        inv.setAvailableQuantity(request.getAvailableQuantity());
        inv.setReservedQuantity(0);
        return toResponse(inventoryRepository.save(inv));
    }

    @Transactional(readOnly = true)
    public InventoryDto.Response getByProductId(String productId) {
        return inventoryRepository.findByProductId(productId)
                .map(this::toResponse)
                .orElseThrow(() -> new IllegalArgumentException("Product not found: " + productId));
    }

    @Transactional(readOnly = true)
    public List<InventoryDto.Response> getAllInventory() {
        return inventoryRepository.findAll().stream()
                .map(this::toResponse)
                .collect(Collectors.toList());
    }

    /**
     * Idempotent reserve: if reservation already exists for orderId+productId, skip silently.
     * Uses @Version optimistic locking to handle concurrent reservations safely.
     */
    @Transactional
    public void reserveStock(Long orderId, String productId, int quantity) {
        if (reservationRepository.existsByOrderIdAndProductId(orderId, productId)) {
            log.warn("Reservation already exists for orderId={}, product={}", orderId, productId);
            return;
        }
        Inventory inv = inventoryRepository.findByProductIdWithLock(productId)
                .orElseThrow(() -> new IllegalArgumentException("Product not found: " + productId));

        if (inv.getAvailableQuantity() < quantity) {
            throw new IllegalStateException(
                    String.format("Insufficient stock for %s. Available: %d, Requested: %d",
                            productId, inv.getAvailableQuantity(), quantity));
        }
        inv.setAvailableQuantity(inv.getAvailableQuantity() - quantity);
        inv.setReservedQuantity(inv.getReservedQuantity() + quantity);
        inventoryRepository.save(inv);

        InventoryReservation reservation = new InventoryReservation();
        reservation.setOrderId(orderId);
        reservation.setProductId(productId);
        reservation.setQuantity(quantity);
        reservation.setStatus(InventoryReservation.ReservationStatus.RESERVED);
        reservationRepository.save(reservation);
        log.info("Stock reserved: product={}, qty={}, orderId={}", productId, quantity, orderId);
    }

    /**
     * Release reserved stock — called during Saga rollback (order cancel).
     */
    @Transactional
    public void releaseReservation(Long orderId) {
        List<InventoryReservation> reservations = reservationRepository.findByOrderId(orderId);
        for (InventoryReservation res : reservations) {
            if (res.getStatus() == InventoryReservation.ReservationStatus.RESERVED) {
                inventoryRepository.findByProductId(res.getProductId()).ifPresent(inv -> {
                    inv.setAvailableQuantity(inv.getAvailableQuantity() + res.getQuantity());
                    inv.setReservedQuantity(Math.max(0, inv.getReservedQuantity() - res.getQuantity()));
                    inventoryRepository.save(inv);
                });
                res.setStatus(InventoryReservation.ReservationStatus.RELEASED);
                reservationRepository.save(res);
                log.info("Reservation released: orderId={}, product={}", orderId, res.getProductId());
            }
        }
    }

    @Transactional
    public InventoryDto.Response updateStock(String productId, int addQuantity) {
        Inventory inv = inventoryRepository.findByProductId(productId)
                .orElseThrow(() -> new IllegalArgumentException("Product not found: " + productId));
        inv.setAvailableQuantity(inv.getAvailableQuantity() + addQuantity);
        return toResponse(inventoryRepository.save(inv));
    }

    private InventoryDto.Response toResponse(Inventory inv) {
        return InventoryDto.Response.builder()
                .id(inv.getId())
                .productId(inv.getProductId())
                .productName(inv.getProductName())
                .availableQuantity(inv.getAvailableQuantity())
                .reservedQuantity(inv.getReservedQuantity())
                .totalStock(inv.getTotalStock())
                .updatedAt(inv.getUpdatedAt())
                .build();
    }
}
