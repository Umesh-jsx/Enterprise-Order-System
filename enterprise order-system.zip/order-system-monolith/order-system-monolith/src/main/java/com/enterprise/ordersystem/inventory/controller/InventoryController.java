package com.enterprise.ordersystem.inventory.controller;

import com.enterprise.ordersystem.inventory.dto.InventoryDto;
import com.enterprise.ordersystem.inventory.service.InventoryService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/inventory")
@RequiredArgsConstructor
@Tag(name = "Inventory API")
public class InventoryController {

    private final InventoryService inventoryService;

    @PostMapping
    @Operation(summary = "Add new product to inventory")
    public ResponseEntity<InventoryDto.Response> addInventory(@Valid @RequestBody InventoryDto.CreateRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(inventoryService.addInventory(request));
    }

    @GetMapping
    @Operation(summary = "Get all inventory")
    public ResponseEntity<List<InventoryDto.Response>> getAllInventory() {
        return ResponseEntity.ok(inventoryService.getAllInventory());
    }

    @GetMapping("/{productId}")
    @Operation(summary = "Get inventory for a specific product")
    public ResponseEntity<InventoryDto.Response> getInventory(@PathVariable String productId) {
        return ResponseEntity.ok(inventoryService.getByProductId(productId));
    }

    @PostMapping("/reserve")
    @Operation(summary = "Reserve stock for an order (idempotent)")
    public ResponseEntity<Void> reserveStock(@Valid @RequestBody InventoryDto.ReserveRequest request) {
        inventoryService.reserveStock(request.getOrderId(), request.getProductId(), request.getQuantity());
        return ResponseEntity.ok().build();
    }

    @PostMapping("/{productId}/restock")
    @Operation(summary = "Add stock quantity to a product")
    public ResponseEntity<InventoryDto.Response> restock(
            @PathVariable String productId,
            @RequestParam int quantity) {
        return ResponseEntity.ok(inventoryService.updateStock(productId, quantity));
    }

    @DeleteMapping("/release/{orderId}")
    @Operation(summary = "Release reserved stock (Saga compensation / order cancel)")
    public ResponseEntity<Void> releaseReservation(@PathVariable Long orderId) {
        inventoryService.releaseReservation(orderId);
        return ResponseEntity.ok().build();
    }
}
