package com.enterprise.ordersystem.order.service;

import com.enterprise.ordersystem.config.KafkaEventBus;
import com.enterprise.ordersystem.inventory.service.InventoryService;
import com.enterprise.ordersystem.order.dto.OrderEvent;
import com.enterprise.ordersystem.order.model.Order;
import com.enterprise.ordersystem.order.repository.OrderRepository;
import com.enterprise.ordersystem.payment.service.PaymentService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

/**
 * Saga choreography coordinator for the monolith.
 *
 * Flow:
 *   createOrder → [Kafka: ORDER_CREATED] → processPayment
 *   processPayment success → [Kafka: PAYMENT_SUCCESS] → reserveInventory
 *   reserveInventory success → Order = COMPLETED
 *   Any failure → compensating rollback (refund + release stock)
 *
 * When Kafka is disabled, the saga is executed synchronously in-process.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class OrderSagaService {

    private final OrderRepository orderRepository;
    private final PaymentService paymentService;
    private final InventoryService inventoryService;
    private final KafkaEventBus kafkaEventBus;

    @Value("${kafka.topic.order-events:order-events}")
    private String orderEventsTopic;

    @Value("${kafka.enabled:false}")
    private boolean kafkaEnabled;

    /**
     * Step 1: Order created — trigger payment step.
     * If Kafka is disabled, calls PaymentService directly (in-process Saga).
     */
    @Transactional
    public void onOrderCreated(Order order) {
        order.setStatus(Order.OrderStatus.PAYMENT_PROCESSING);
        orderRepository.save(order);

        if (!kafkaEnabled) {
            log.info("[SAGA-SYNC] Triggering payment directly for orderId: {}", order.getId());
            executeSyncPayment(order);
            return;
        }

        kafkaEventBus.publishOrderEvent(orderEventsTopic, OrderEvent.builder()
                .eventType("ORDER_CREATED")
                .orderId(order.getId())
                .userId(order.getUserId())
                .productId(order.getProductId())
                .quantity(order.getQuantity())
                .totalAmount(order.getTotalAmount())
                .status(order.getStatus().name())
                .timestamp(LocalDateTime.now())
                .build());
    }

    /**
     * Synchronous Saga execution (Kafka disabled).
     * Simulates the full event chain in-process without any broker.
     */
    private void executeSyncPayment(Order order) {
        try {
            // Simulate payment — 90% success rate
            boolean paymentSuccess = Math.random() > 0.1;

            if (paymentSuccess) {
                handlePaymentSuccess(order.getId());
            } else {
                handlePaymentFailure(order.getId(), "Insufficient funds (simulated)");
            }
        } catch (Exception e) {
            log.error("[SAGA-SYNC] Payment step failed for orderId={}: {}", order.getId(), e.getMessage());
            handlePaymentFailure(order.getId(), e.getMessage());
        }
    }

    @Transactional
    public void handlePaymentSuccess(Long orderId) {
        log.info("[SAGA] Payment success for orderId: {}", orderId);
        Order order = getOrder(orderId);
        if (order == null) return;

        order.setStatus(Order.OrderStatus.PAYMENT_COMPLETED);
        orderRepository.save(order);

        if (!kafkaEnabled) {
            executeSyncInventory(order);
            return;
        }

        kafkaEventBus.publishOrderEvent(orderEventsTopic, OrderEvent.builder()
                .eventType("RESERVE_INVENTORY")
                .orderId(order.getId())
                .userId(order.getUserId())
                .productId(order.getProductId())
                .quantity(order.getQuantity())
                .totalAmount(order.getTotalAmount())
                .timestamp(LocalDateTime.now())
                .build());
    }

    private void executeSyncInventory(Order order) {
        try {
            inventoryService.reserveStock(order.getId(), order.getProductId(), order.getQuantity());
            handleInventoryReserved(order.getId());
        } catch (Exception e) {
            log.warn("[SAGA-SYNC] Inventory step failed for orderId={}: {}", order.getId(), e.getMessage());
            handleInventoryFailure(order.getId(), e.getMessage());
        }
    }

    @Transactional
    public void handlePaymentFailure(Long orderId, String reason) {
        log.warn("[SAGA] Payment failed for orderId={}: {}", orderId, reason);
        Order order = getOrder(orderId);
        if (order == null) return;
        order.setStatus(Order.OrderStatus.SAGA_ROLLED_BACK);
        order.setFailureReason("Payment failed: " + reason);
        orderRepository.save(order);
    }

    @Transactional
    public void handleInventoryReserved(Long orderId) {
        log.info("[SAGA] Inventory reserved for orderId: {}", orderId);
        Order order = getOrder(orderId);
        if (order == null) return;
        order.setStatus(Order.OrderStatus.COMPLETED);
        orderRepository.save(order);
        log.info("[SAGA] Order COMPLETED successfully: {}", orderId);
    }

    @Transactional
    public void handleInventoryFailure(Long orderId, String reason) {
        log.warn("[SAGA] Inventory failed for orderId={}: {}", orderId, reason);
        Order order = getOrder(orderId);
        if (order == null) return;

        // Compensating transaction: refund payment
        try {
            paymentService.refundPayment(orderId);
        } catch (Exception e) {
            log.error("[SAGA] Refund failed during rollback for orderId={}: {}", orderId, e.getMessage());
        }

        // Compensating transaction: release inventory
        try {
            inventoryService.releaseReservation(orderId);
        } catch (Exception e) {
            log.error("[SAGA] Inventory release failed for orderId={}: {}", orderId, e.getMessage());
        }

        order.setStatus(Order.OrderStatus.SAGA_ROLLED_BACK);
        order.setFailureReason("Inventory failed: " + reason);
        orderRepository.save(order);
        log.warn("[SAGA] Rolled back orderId: {}", orderId);
    }

    private Order getOrder(Long orderId) {
        return orderRepository.findById(orderId).orElseGet(() -> {
            log.error("[SAGA] Order not found: {}", orderId);
            return null;
        });
    }
}
