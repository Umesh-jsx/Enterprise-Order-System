package com.enterprise.ordersystem.config;

import com.enterprise.ordersystem.order.dto.OrderEvent;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;

/**
 * Central Kafka event bus used by all domain services in the monolith.
 * When kafka.enabled=false, events are logged/simulated (no broker needed).
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class KafkaEventBus {

    private final KafkaTemplate<String, String> kafkaTemplate;
    private final ObjectMapper objectMapper;

    @Value("${kafka.enabled:false}")
    private boolean kafkaEnabled;

    public void publish(String topic, String key, Object event) {
        if (!kafkaEnabled) {
            log.warn("[KAFKA-DISABLED] Simulated publish → topic='{}', key='{}', event={}",
                    topic, key, event);
            return;
        }
        try {
            String payload = objectMapper.writeValueAsString(event);
            kafkaTemplate.send(topic, key, payload)
                    .whenComplete((result, ex) -> {
                        if (ex != null) {
                            log.error("[KAFKA] Failed to publish to topic='{}': {}", topic, ex.getMessage());
                        } else {
                            log.info("[KAFKA] Published to topic='{}', partition={}, offset={}",
                                    topic,
                                    result.getRecordMetadata().partition(),
                                    result.getRecordMetadata().offset());
                        }
                    });
        } catch (Exception e) {
            log.error("[KAFKA] Serialization error for topic='{}': {}", topic, e.getMessage());
        }
    }

    public void publishOrderEvent(String topic, OrderEvent event) {
        publish(topic, String.valueOf(event.getOrderId()), event);
    }
}
