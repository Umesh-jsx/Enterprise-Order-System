package com.enterprise.ordersystem.payment.service;

import com.enterprise.ordersystem.config.KafkaEventBus;
import com.enterprise.ordersystem.order.dto.OrderEvent;
import com.enterprise.ordersystem.payment.dto.PaymentDto;
import com.enterprise.ordersystem.payment.model.Payment;
import com.enterprise.ordersystem.payment.repository.PaymentRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class PaymentService {

    private final PaymentRepository paymentRepository;
    private final KafkaEventBus kafkaEventBus;

    @Value("${kafka.topic.payment-results:payment-results}")
    private String paymentResultsTopic;

    /**
     * Process payment — idempotent: returns existing payment if already processed for this orderId.
     */
    @Transactional
    public PaymentDto.Response processPayment(PaymentDto.CreateRequest request) {
        log.info("Processing payment for orderId: {}", request.getOrderId());

        return paymentRepository.findByOrderId(request.getOrderId())
                .map(existing -> {
                    log.warn("Payment already exists for orderId: {}", request.getOrderId());
                    return toResponse(existing);
                })
                .orElseGet(() -> {
                    Payment payment = new Payment();
                    payment.setOrderId(request.getOrderId());
                    payment.setUserId(request.getUserId());
                    payment.setAmount(request.getAmount());
                    payment.setStatus(Payment.PaymentStatus.SUCCESS);
                    payment.setTransactionId("TXN-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase());
                    Payment saved = paymentRepository.save(payment);

                    // Publish payment result for Saga
                    kafkaEventBus.publishOrderEvent(paymentResultsTopic, OrderEvent.builder()
                            .eventType("PAYMENT_SUCCESS")
                            .orderId(saved.getOrderId())
                            .userId(saved.getUserId())
                            .totalAmount(saved.getAmount())
                            .status("SUCCESS")
                            .timestamp(LocalDateTime.now())
                            .build());

                    log.info("Payment processed id={}, txn={}", saved.getId(), saved.getTransactionId());
                    return toResponse(saved);
                });
    }

    @Transactional(readOnly = true)
    public PaymentDto.Response getPaymentById(Long id) {
        return paymentRepository.findById(id)
                .map(this::toResponse)
                .orElseThrow(() -> new IllegalArgumentException("Payment not found: " + id));
    }

    @Transactional(readOnly = true)
    public PaymentDto.Response getPaymentByOrderId(Long orderId) {
        return paymentRepository.findByOrderId(orderId)
                .map(this::toResponse)
                .orElseThrow(() -> new IllegalArgumentException("Payment not found for orderId: " + orderId));
    }

    @Transactional(readOnly = true)
    public List<PaymentDto.Response> getAllPayments() {
        return paymentRepository.findAll().stream()
                .map(this::toResponse)
                .collect(Collectors.toList());
    }

    /**
     * Refund a payment as part of Saga rollback.
     */
    @Transactional
    public void refundPayment(Long orderId) {
        paymentRepository.findByOrderId(orderId).ifPresent(payment -> {
            if (payment.getStatus() == Payment.PaymentStatus.SUCCESS) {
                payment.setStatus(Payment.PaymentStatus.REFUNDED);
                paymentRepository.save(payment);
                log.info("Payment refunded for orderId: {}", orderId);
            }
        });
    }

    private PaymentDto.Response toResponse(Payment p) {
        return PaymentDto.Response.builder()
                .id(p.getId())
                .orderId(p.getOrderId())
                .userId(p.getUserId())
                .amount(p.getAmount())
                .status(p.getStatus())
                .transactionId(p.getTransactionId())
                .failureReason(p.getFailureReason())
                .createdAt(p.getCreatedAt())
                .updatedAt(p.getUpdatedAt())
                .build();
    }
}
