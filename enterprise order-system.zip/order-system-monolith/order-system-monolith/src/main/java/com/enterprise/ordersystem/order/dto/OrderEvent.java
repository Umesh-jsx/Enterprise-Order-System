package com.enterprise.ordersystem.order.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class OrderEvent {
    private String eventType;   // ORDER_CREATED, PAYMENT_SUCCESS, PAYMENT_FAILED, etc.
    private Long orderId;
    private Long userId;
    private String productId;
    private Integer quantity;
    private BigDecimal totalAmount;
    private String status;
    private String message;
    private LocalDateTime timestamp;
}
